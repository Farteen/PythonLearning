from distutils.core import setup

setup (
	name 		=	'nested_print',
	version 	=	'1.0.0',
	py_modules	= 	['nested_print'],
	author		= 	'farteen',
	author_email	=	'934628017@qq.com',
	url		=	'http://github.com/farteen',
	description	=	'A simple printer'
)

