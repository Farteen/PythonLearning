from distutils.core import setup

setup (
	name 		=	'nester',
	version 	=	'1.0.0',
	py_modules	= 	['nester'],
	author		= 	'farteen',
	author_email	=	'934628017@qq.com',
	url		=	'http://github.com/farteen',
	description	=	'A simple printer'
)

